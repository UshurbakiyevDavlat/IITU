public abstract class Contact {
    public Contact() {
    }
    public abstract String getPersonalData();
    public  abstract  String getPhone();
    void printContactData(){

    }




    
}
