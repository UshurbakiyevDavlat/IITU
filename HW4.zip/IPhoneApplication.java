public class IPhoneApplication implements PhoneApplication {
    private String name;
    private Contact allContacts[] = new Contact[1000];
    private int contactSize = 0 ;

    @Override
    public void addContact(Contact c) {
        for (int i = 0; i < 10; i++) {
            this.allContacts[i] = c;
        }
    }

    @Override
    public void printContact() {
        for(int i = 0; i<10;i++) {
            System.out.println("Phone:"+this.allContacts[i].getPhone()+" Personal data:" + this.allContacts[i].getPersonalData());
        }
    }

}
