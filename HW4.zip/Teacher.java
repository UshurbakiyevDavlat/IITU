public class Teacher extends User {
    private String  nickName;
    private  String Status;
    private String subject[] = new String [10];
    private int sizeOfSubjects = 0;


    public Teacher(int id, String login, String password, String nickName, String status, String[] subject, int sizeOfSubjects) {
        super(id, login, password);
        this.nickName = nickName;
        Status = status;
        this.subject = subject;
        this.sizeOfSubjects = sizeOfSubjects;
    }

    public Teacher(String nickName, String status, String[] subject, int sizeOfSubjects) {
        this.nickName = nickName;
        Status = status;
        this.subject = subject;
        this.sizeOfSubjects = sizeOfSubjects;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String[] getSubject() {
        return subject;
    }


    public int getSizeOfSubjects() {
        return sizeOfSubjects;
    }
    public void addSubject(String subjects) {
        int j =0;
        for(int i =0; i<10;i++) {
            this.subject[i] = subjects;

        }

    }

    @Override
    String getUserData() {
        return "Nickname "+nickName+" Password "+getPassword()+"  Size Of Subjects "+ sizeOfSubjects + " Status " + getStatus() +" Subject ";
    }
}
