public class FlashLight {
    private  Battery batteries [];

    public FlashLight(Battery[] batteries) {
        this.batteries = batteries;
    }

    public FlashLight() {
    }

    public Battery[] getBatteries() {
        return batteries;
    }

    public void setBatteries(Battery[] batteries) {
        this.batteries = batteries;
    }
    public double getTotalPower(){
        double totalPower=0;
        for(int i = 0; i < 10 ; i++){
           totalPower += batteries[i].getPower();
        }
        return  totalPower;
    }
    public double getTotalEnergy(){
        double totalEnergy = 0;
        for(int i =0; i < 10; i++){
            totalEnergy += batteries[i].getPower() * batteries[i].getLifeTime();
        }
        return  totalEnergy;
    }
    public double getTotalLifeTime(){
            double totalLifeTime = 0;
            for(int i =0; i < 10; i++){
                totalLifeTime += batteries[i].getLifeTime();
            }
            return totalLifeTime;
    }

}
