import java.awt.desktop.SystemSleepEvent;
import java.util.Scanner;
public class Main {

    public static void MachineTask(){
        Scanner sc = new Scanner(System.in);

        Engine [] engines = new Engine[20];
        FerrariEngine [] ferrariEngines = new FerrariEngine[10];
        Renault [] renaults = new Renault[10];

        System.out.println("Enter the Feraries:");
        for(int i = 0 ; i < 10 ; i++){
            ferrariEngines[i] = new FerrariEngine(sc.nextDouble(),sc.nextInt(),sc.nextDouble());
        }
        System.out.println("Enter the Renaults:");
        for(int i = 0 ; i < 10 ; i++){
            renaults[i] = new Renault(sc.nextDouble(),sc.nextInt(),sc.nextDouble(),sc.nextDouble());
        }
        for(int i = 0; i <10 ; i++){
            engines[i] = ferrariEngines[i];
        }
        for(int i = 10 ; i < 20; i++){
            engines[i] = renaults[i-10];
        }
        for(int i = 0; i < 20 ; i++) {
            System.out.println("Max speed for machine number "+ (i+1) + ": " + engines[i].getMaxSpeed());
        }
    }
    public static void BatteryTask(){
            Scanner sc = new Scanner(System.in);
            Battery[]batteries = new Battery[10];
            ToshibaBattery [] toshibaBatteries = new ToshibaBattery[5];
            DuracellBattery [] duracellBatteries = new DuracellBattery[5];
            FlashLight [] flashLights = new FlashLight[5];

                System.out.println("Enter data about ToshibaBatteries double voltage, double currency, double energy, double extraEnergy");
            for(int i = 0; i < 5 ; i++) {
                toshibaBatteries[i] = new ToshibaBattery(sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
            }
                 System.out.println("Enter data about DuracellBatteries double voltage, double currency, double energy, double internalVolage");
            for(int i = 0; i < 5; i++) {
                duracellBatteries[i] = new DuracellBattery(sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
            }

                for(int i = 0 ; i <5 ; i++){
                    batteries[i] = toshibaBatteries[i];
                 }

                for(int i = 5; i < 10;i++){
                    batteries[i]=duracellBatteries[i-5];
                }

            for(int i = 0; i < 5; i++){
                flashLights[i] = new FlashLight(batteries);
            }

            for(int i = 0; i<10 ;i++){
                System.out.println("lifetime for " + (i+1) + "-th flashLight:" + batteries[i].getLifeTime());
            }
            double maxLifeTime = 0;
            int indMaxLifeTime = 0;
            for(int i =0; i<10; i++){
                if(maxLifeTime<batteries[i].getLifeTime()) {
                    maxLifeTime = batteries[i].getLifeTime();
                    indMaxLifeTime = i;
                }
            }
            System.out.println("Data about flashLight with maximum LifeTime:");
            System.out.println("LifeTime:"+batteries[indMaxLifeTime].getLifeTime() + " Power:" + batteries[indMaxLifeTime].getPower());


    }
    public  static void UserTask(){
            Scanner sc = new Scanner(System.in);
            Teacher [] teachers = new Teacher[10];
            Student [] students = new Student[10];
            String [] subjects = new String[10];
            String [] sub = new String[10];
            int [] size = new int [10];
            subjects[0] = "Math";
            subjects[1] = "Physics";
            subjects[2] = "PI";
            subjects[3] = "English";
            subjects[4] = "Russian";
            subjects[5] = "Kazakh";
            subjects[6] = "Java";
            subjects[7] = "Python";
            subjects[8] = "PhP";
            subjects[9] = "Algoritmization";



            System.out.println("Enter Students atribute such as int id, String login, String password, String name, String surname, String group, double gpa");
            for(int i =0; i < 10 ;i++){
                students[i] = new Student(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.nextDouble());
            }

            System.out.println("Enter Teachers atribute such as int id, String login, String password, String nickName, String status, String[] subject, int sizeOfSubjects");
            for(int i = 0; i <10;i++){
                teachers[i] = new Teacher(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.next(),subjects,sc.nextInt());
            }

        System.out.println("----------------------");
            for(int i =0;i<10;i++){
               System.out.println("Student:"+students[i].getUserData());
            }
        System.out.println("----------------------");

                    sub = teachers[0].getSubject();
                    for(int i =0; i <10 ;i++) {
                        size[i] = teachers[0].getSizeOfSubjects();
                    }
            for(int i=0;i<10;i++){
               System.out.println("Teacher:"+teachers[i].getUserData());
               for(int j = 0 ; j<size[i] ; j++){
                   System.out.println(sub[i]);
               }
            }

    }

    public  static void ContactTask(){
        Scanner sc = new Scanner(System.in);
        IphoneContact[]iphoneContacts = new IphoneContact[10];
        SamsungContact[]samsungContacts  = new SamsungContact[10];

        String[]phones = new String[3];




        IPhoneApplication ipAp = new IPhoneApplication();
        SamsungApplication samAp = new SamsungApplication();



        System.out.println("Enter the phones for samsung: ");
         for(int i = 0;i<3;i++) {
            phones[i] = sc.next();
    }
            System.out.println("Enter the Iphone atributes such as :int id, String name, String surname, String firstPhone, String secondPhone, String thirdPhone");
        for(int i = 0; i<10; i++) {
            iphoneContacts[i] = new IphoneContact(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.next(),sc.next());
        }
        System.out.println("Enter the Samsung such as : int id, String fullName");
        for(int i = 0; i<10 ; i++) {
            samsungContacts[i] = new SamsungContact(sc.nextInt(),sc.next(),phones);
        }

        Contact [] contacts = new Contact[20];


        for(int i = 0 ;i< 10;i++){
            contacts[i] = iphoneContacts[i];
        }

        for(int j = 10 ; j<20  ; j++){
            contacts[j] = samsungContacts[j-10];
        }

        for(int i = 0;i<10;i++){
            ipAp.addContact(contacts[i]);
        }
        for(int i = 10; i < 20; i++) {
            samAp.addContact(contacts[i]);
        }

            System.out.println("Data for IPHONE USERS:\n");
        ipAp.printContact();
        System.out.println("--------------------------------------------------------------------");
        System.out.println("Data for SAMSUNG USERS:\n");
        samAp.printContact();

    }


    public  static  void main (String[]args){
            //MachineTask();
            //BatteryTask();
            //UserTask();
           // ContactTask();
    }
}
//Example for 4 task is in PhoneApplication.java (interface)
//Example for 1 task
/*
*1,6
1000
300
2
1500
121
1,8
900
150
2,5
1100
110
3
1300
400
1,5
2000
300
1,5
2000
300
1,5
2000
300
1,5
2000
300
1,5
2000
300
*////for renaults
/* 3,4
1400
200
1400

3,4
1400
200
1400
3,4
1400
200
1400
3,4
1400
200
1400
3,4
1400
200
1400
3,4
1400
200
1400
3,4
1400
200
1400
3,4
1400
200
1400
3,4
1400
200
1400
3,4
1400
200
1400
*
* */
/*ex 2 task
220
2
3000
110
220
1
2900
110
440
2
3000
110
120
1
1200
110
140
2
1500
110
*
220
2
3020
110
220
1
2909
140
440
2
3100
110
120
1
1220
140
140
2
1540
140
*
*for 3 task
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5
1 Dav mal Davlat Ushurbakiev Itse1909 3,5

2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
2 Davlat2000 dada2000 Devil tutor 2
* */