public interface PhoneApplication {
    public void addContact(Contact c);
    public void printContact();
}
/*
*
123
123
123
*
 1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
1 Davlat Ushurbakiyev 231 231 123
*
* 1 Davlat
1 Davlat
1 Davlat
1 Davlat
1 Davlat
1 Davlat
1 Davlat
1 Davlat
1 Davlat
1 Davlat
* */