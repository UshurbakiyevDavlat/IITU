public abstract class Battery {
    public abstract  double getPower();
    public abstract  double getLifeTime();
}
