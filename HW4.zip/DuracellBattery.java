public class DuracellBattery extends Battery {
    private double voltage;
    private double currency;
    private double energy;
    private double internalVolage;

    public DuracellBattery(double voltage, double currency, double energy, double internalVolage) {
        this.voltage = voltage;
        this.currency = currency;
        this.energy = energy;
        this.internalVolage = internalVolage;
    }

    public double getVoltage() {
        return voltage;
    }

    public void setVoltage(double voltage) {
        this.voltage = voltage;
    }

    public double getCurrency() {
        return currency;
    }

    public void setCurrency(double currency) {
        this.currency = currency;
    }

    public double getEnergy() {
        return energy;
    }

    public void setEnergy(double energy) {
        this.energy = energy;
    }

    public double getInternalVolage() {
        return internalVolage;
    }

    public void setInternalVolage(double internalVolage) {
        this.internalVolage = internalVolage;
    }

    @Override
    public double getPower() {
        return currency * voltage; //P=I*U
    }

    @Override
    public double getLifeTime() {
        return energy/getPower(); //t= E/(I*U)
    }

}
